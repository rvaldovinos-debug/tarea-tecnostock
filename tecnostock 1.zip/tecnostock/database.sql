-- TecnoStock - Modelo relacional
SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS tecnostock CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tecnostock;

CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre     VARCHAR(100) NOT NULL,
  correo     VARCHAR(120) NOT NULL UNIQUE,
  clave      VARCHAR(255) NOT NULL COMMENT 'hash bcrypt (password_hash)',
  estado     TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '1=activo, 0=inactivo'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categorias (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre       VARCHAR(80)  NOT NULL UNIQUE,
  descripcion  VARCHAR(255) NULL,
  estado       TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS productos (
  id_producto  INT AUTO_INCREMENT PRIMARY KEY,
  codigo       VARCHAR(30)   NOT NULL UNIQUE,
  nombre       VARCHAR(120)  NOT NULL,
  descripcion  TEXT          NULL,
  precio       DECIMAL(10,2) NOT NULL,
  stock_actual INT           NOT NULL DEFAULT 0,
  stock_minimo INT           NOT NULL DEFAULT 0,
  estado       TINYINT(1)    NOT NULL DEFAULT 1,
  id_categoria INT           NOT NULL,
  CONSTRAINT chk_precio       CHECK (precio >= 0),
  CONSTRAINT chk_stock_actual CHECK (stock_actual >= 0),
  CONSTRAINT chk_stock_minimo CHECK (stock_minimo >= 0),
  CONSTRAINT fk_productos_categoria FOREIGN KEY (id_categoria)
    REFERENCES categorias (id_categoria) ON UPDATE CASCADE ON DELETE RESTRICT,
  INDEX idx_productos_nombre (nombre)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS movimientos (
  id_movimiento INT AUTO_INCREMENT PRIMARY KEY,
  fecha_hora    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  tipo          ENUM('entrada','salida') NOT NULL,
  cantidad      INT          NOT NULL,
  observacion   VARCHAR(255) NULL,
  id_producto   INT          NOT NULL,
  id_usuario    INT          NOT NULL,
  CONSTRAINT chk_cantidad CHECK (cantidad > 0),
  CONSTRAINT fk_mov_producto FOREIGN KEY (id_producto)
    REFERENCES productos (id_producto) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_mov_usuario FOREIGN KEY (id_usuario)
    REFERENCES usuarios (id_usuario) ON UPDATE CASCADE ON DELETE RESTRICT,
  INDEX idx_mov_fecha (fecha_hora)
) ENGINE=InnoDB;

-- Datos iniciales (usuario de prueba: admin@tecnostock.cl / admin123)
INSERT INTO usuarios (nombre, correo, clave) VALUES
('Encargado de Inventario', 'admin@tecnostock.cl', '$2y$10$K04tDlKOmOwIPuyZwwybxuObTTIVmMbuswF10h4N7VOMoC5z3e1yi');

INSERT INTO categorias (nombre, descripcion) VALUES
('Audio', 'Audífonos y parlantes'),
('Cables y cargadores', 'Cables, adaptadores y cargadores'),
('Almacenamiento', 'Pendrives, discos y tarjetas de memoria'),
('Periféricos', 'Mouse, teclados y accesorios de escritorio'),
('Fundas y protección', 'Fundas, láminas y estuches');

INSERT INTO productos (codigo, nombre, descripcion, precio, stock_actual, stock_minimo, id_categoria) VALUES
('AUD-001', 'Audífonos Bluetooth', 'Audífonos inalámbricos con estuche de carga', 19990, 25, 10, 1),
('CAB-001', 'Cable USB-C 1m', 'Cable de carga y datos USB-C', 3990, 8, 15, 2),
('ALM-001', 'Pendrive 64GB', 'Memoria USB 3.0', 6990, 30, 10, 3),
('PER-001', 'Mouse inalámbrico', 'Mouse óptico 2.4GHz', 8990, 5, 5, 4),
('FUN-001', 'Funda notebook 15"', 'Funda acolchada impermeable', 12990, 12, 6, 5);

INSERT INTO movimientos (tipo, cantidad, observacion, id_producto, id_usuario)
SELECT 'entrada', stock_actual, 'Stock inicial', id_producto, 1 FROM productos;
